import pickle
def set_pref(l):
    x=pickle.load(open("D:\\Food_pairing\\final\\data\\output\\user_preferences","rb"))
    x=x+l
    pickle.dump(x,open("D:\\Food_pairing\\final\\data\\output\\user_preferences","wb"))
    return x
def get_pref():
    return pickle.load(open("D:\\Food_pairing\\final\\data\\output\\user_preferences","rb"))

