import numpy as np
import pickle
from sklearn.metrics.pairwise import cosine_similarity
# from get_recipe_name import get_Rec_name


def find_similar_recipes(recipe_id, recipe_embeddings, top_n=5):
    # Get the embedding of the given recipe
    query_embedding = recipe_embeddings.get(recipe_id)
    if query_embedding is None:
        print(f"Recipe with ID {recipe_id} not found.")
        return []

    # Calculate cosine similarity between the query recipe and all other recipes
    similarities = {}
    for r_id, r_embedding in recipe_embeddings.items():
        similarity = cosine_similarity([query_embedding], [r_embedding])[0][0]
        similarities[r_id] = similarity

    # Sort the similarities and get the top N similar recipes
    similar_recipes = sorted(similarities.items(), key=lambda x: x[1], reverse=True)[:top_n]
   
    return similar_recipes


