import numpy as np
from scipy.spatial.distance import cosine
import pickle

def calculate_similarity(x, y):
    with open("D:\Food_pairing\\final\data\\output\\recipe_embeddings.pkl",'rb') as f:
        c=pickle.load(f)
    recipe1_embedding=c[x]
    recipe2_embedding=c[y]
    similarity_score = 1 - cosine(recipe1_embedding, recipe2_embedding)
    return similarity_score




