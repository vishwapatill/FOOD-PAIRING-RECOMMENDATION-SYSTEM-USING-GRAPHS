import tkinter as tk
from tkinter import messagebox
from PIL import Image, ImageTk
import requests
from io import BytesIO
import pickle
import pandas as pd
from get_recommendations import get_recommendations
from calculate_score import calculate_similarity
from find_nearest_ing import find_sub

recipe_emb=pickle.load(open("D:\Food_pairing\\final\data\output\\recipe_embeddings.pkl",'rb'))
node_emb=pickle.load(open("D:\Food_pairing\\final\data\output\embedings.pickle",'rb'))
csv_file=pd.read_csv("D:\Food_pairing\\final\data\indianRecepies\Cleaned_Indian_Food_Dataset.csv")

user_preference=pickle.load(open("D:\Food_pairing\\final\data\\output\\user_preference",'rb'))



search_results = ["Result 1", "Result 2", "Result 3", "Result 4", "Result 5"]


def open_home():
    # Show home page
    home_frame.pack()
    search_frame.pack_forget()
    preferences_frame.pack_forget()
    substitutes_frame.pack_forget()
    score_frame.pack_forget()
    frame2.pack_forget()
    frame3.pack_forget()

def open_search():
    # Show search page
    home_frame.pack_forget()
    search_frame.pack()
    preferences_frame.pack_forget()
    substitutes_frame.pack_forget()
    score_frame.pack_forget()
    frame2.pack_forget()
    frame3.pack_forget()

def open_preferences():
    # Show preferences page
    home_frame.pack_forget()
    search_frame.pack_forget()
    preferences_frame.pack()
    substitutes_frame.pack_forget()
    score_frame.pack_forget()
    frame2.pack_forget()
    frame3.pack_forget()
    preferences_list.delete(0,tk.END)
    global user_preference
    print(user_preference)
    for i in user_preference:
        preferences_list.insert(tk.END,csv_file["TranslatedRecipeName"].iloc[i])

def open_substitutes():
    # Show substitutes page
    home_frame.pack_forget()
    search_frame.pack_forget()
    preferences_frame.pack_forget()
    substitutes_frame.pack()
    score_frame.pack_forget()
    frame2.pack_forget()
    frame3.pack_forget()

def open_score():
    # Show score page
    home_frame.pack_forget()
    search_frame.pack_forget()
    preferences_frame.pack_forget()
    substitutes_frame.pack_forget()
    score_frame.pack()
    frame2.pack()
    frame3.pack()


def get_recipe_data( row_number):
    print(row_number)
    row = csv_file.iloc[row_number]
    return {
        "name": row["TranslatedRecipeName"],
        "image_path": row["image-url"],
        "description": row["TranslatedIngredients"]
    }

def display_recipe(recipe):
    get_recipe_data(recipe)
    messagebox.showinfo(title=recipe['name'], message=recipe['description'])
    
def regenerate():
    print("Regenerating recommended recipes")
    recipes=[]
    recommended_list.delete(0, tk.END)
    r_list=get_recommendations(user_preference,recipe_emb)
    
    for i in r_list:
        recipes.append(get_recipe_data(i))
    for recipe in recipes:
        recommended_list.insert(tk.END, recipe['name'])
        # Bind a click event to each recipe name to display the image and description
        recommended_list.bind("<Double-Button-1>", lambda event, recipe=recipe: display_recipe(recipe))


def search_recipe():
   search_results_list.delete(0, tk.END)
   q=search_entry.get().lower()
   for i in csv_file['TranslatedRecipeName']:
    if((i.lower()).find(q)!=-1):
        search_results_list.insert(tk.END, i)

def search_rec_pref():
    preferences_search_results_list.delete(0, tk.END)
    q=preferences_search_entry.get().lower()
    print(q)
    for i in csv_file['TranslatedRecipeName']:
        if((i.lower()).find(q)!=-1):
            preferences_search_results_list.insert(tk.END, i)
def to_id(r):
    return csv_file.index[csv_file['TranslatedRecipeName']==r].to_list()[0]
def add_preference():
    # Get the selected item from search results
    global user_preference
    selected = preferences_search_results_list.curselection()
    if selected:
        item = preferences_search_results_list.get(selected[0])
        user_preference.append(csv_file.index[csv_file['TranslatedRecipeName']==item].to_list()[0])
        print(user_preference)
        preferences_list.insert(tk.END, item)
    pickle.dump(user_preference,open("D:\Food_pairing\\final\data\\output\\user_preference","wb"))

def remove_preference():
    global user_preference
    # Get the selected item from preferences
    index=preferences_list.curselection()
    selected = preferences_list.get(index)
    print(to_id(selected))
    print(user_preference)
    print("before",user_preference)
    if selected:
        user_preference.remove(to_id(selected))
        print(user_preference)
        preferences_list.delete(index)
        pickle.dump(user_preference,open("D:\Food_pairing\\final\data\\output\\user_preference","wb"))


def calculate_score_search():
    # Get the text from the entry boxes
    recipe1_text = recipe1_entry.get().strip()
    recipe2_text = recipe2_entry.get().strip()
    recipe1_search_results_list.delete(0, tk.END)
    recipe2_search_results_list.delete(0, tk.END)
    print(recipe1_text,recipe2_text)
    for i in csv_file['TranslatedRecipeName']:
        if((i.lower()).find(recipe1_text)!=-1):
            recipe1_search_results_list.insert(tk.END, i)

    for i in csv_file['TranslatedRecipeName']:
        if((i.lower()).find(recipe2_text)!=-1):
            recipe2_search_results_list.insert(tk.END, i)
recipe1_set=""
recipe2_set=""
def set_recipe1():
   global recipe1_set
   recipe1_set=recipe1_search_results_list.get(recipe1_search_results_list.curselection())
def set_recipe2():
    global recipe2_set
    recipe2_set=recipe2_search_results_list.get(recipe2_search_results_list.curselection())
def hit_cal():
    global recipe1_set
    global recipe2_set
    recipe1_id=to_id(recipe1_set)
    recipe2_id=to_id(recipe2_set)
    score_label.config(text=calculate_similarity(int(recipe1_id),int(recipe2_id)))

def search_subs():
    substitutes_search_results_list.delete(0,tk.END)
    d=find_sub(substitutes_search_entry.get().lower())
    print(d)
    for i in d:
        substitutes_search_results_list.insert(tk.END,i)


        
root = tk.Tk()
root.title("Food Pairing Recommendation System")

# Create a frame for the options
options_frame = tk.Frame(root)
options_frame.pack(fill=tk.X)

# Create buttons for each option


home_btn = tk.Button(options_frame, text="Home", command=open_home)
home_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

search_btn = tk.Button(options_frame, text="Search", command=open_search)
search_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

preferences_btn = tk.Button(options_frame, text="Set Preferences", command=open_preferences)
preferences_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

substitute_btn = tk.Button(options_frame, text="Ingredient Substitute", command=open_substitutes)
substitute_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)

score_btn = tk.Button(options_frame, text="Score", command=open_score)
score_btn.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)


# Create a frame for the home page content
home_frame = tk.Frame(root)

heading_label = tk.Label(home_frame, text="Recommended Recipes", font=("Helvetica", 16))
heading_label.pack()

regenerate_btn = tk.Button(home_frame, text="Regenerate", command=regenerate)
regenerate_btn.pack()

recommended_list = tk.Listbox(home_frame, width=50, height=10)
recommended_list.pack()

#search Page
search_frame = tk.Frame(root)

ingredient_label = tk.Label(search_frame, text="Enter Recipe:")
ingredient_label.pack()

search_entry = tk.Entry(search_frame)
search_entry.pack()

search_button = tk.Button(search_frame, text="Search", command=search_recipe)
search_button.pack()

search_results_list = tk.Listbox(search_frame, width=50, height=10)
search_results_list.pack()


# Create a frame for the preferences page content
preferences_frame = tk.Frame(root)

preferences_heading = tk.Label(preferences_frame, text="Set Preferences", font=("Helvetica", 16))
preferences_heading.pack()

preferences_search_label = tk.Label(preferences_frame, text="Enter search query:")
preferences_search_label.pack()

preferences_search_entry = tk.Entry(preferences_frame)
preferences_search_entry.pack()

preferences_search_button = tk.Button(preferences_frame, text="Search", command=search_rec_pref)
preferences_search_button.pack()

preferences_search_results_list = tk.Listbox(preferences_frame, width=50, height=10)
preferences_search_results_list.pack()

# Add add button for adding to preferences in preferences
preferences_add_button = tk.Button(preferences_frame, text="Add", command=add_preference)
preferences_add_button.pack()

# Add listbox for preferences
preferences_list = tk.Listbox(preferences_frame, width=50, height=10)
preferences_list.pack()

# Add remove button for removing from preferences
remove_button = tk.Button(preferences_frame, text="Remove", command=remove_preference)
remove_button.pack()



# Create a frame for the substitutes page content
substitutes_frame = tk.Frame(root)

substitutes_search_label = tk.Label(substitutes_frame, text="Enter ingredient:")
substitutes_search_label.pack()

substitutes_search_entry = tk.Entry(substitutes_frame)
substitutes_search_entry.pack()

substitutes_search_button = tk.Button(substitutes_frame, text="Search", command=search_subs)
substitutes_search_button.pack()

substitutes_search_results_list = tk.Listbox(substitutes_frame, width=50, height=10)
substitutes_search_results_list.pack()



# Create a frame for the score page content
score_frame = tk.Frame(root)

frame2=tk.Frame(score_frame,height=500,width=500)
# Add heading for score
score_heading = tk.Label(score_frame, text="Score", font=("Helvetica", 16))
score_heading.pack()

# Add entry boxes and labels for recipe 1 and recipe 2
recipe1_label = tk.Label(frame2, text="Recipe 1:")
recipe1_label.grid(row=0,column=0)

recipe1_entry = tk.Entry(frame2)
recipe1_entry.grid(row=0,column=1)


recipe1_search_results_list = tk.Listbox(frame2, width=50, height=10)
recipe1_search_results_list.grid(row=1,column=0,columnspan=2)


recipe2_label = tk.Label(frame2, text="Recipe 2:")
recipe2_label.grid(row=0,column=2)

recipe2_entry = tk.Entry(frame2)
recipe2_entry.grid(row=0,column=3)

recipe2_search_results_list = tk.Listbox(frame2, width=50, height=10)
recipe2_search_results_list.grid(row=1,column=2,columnspan=2)
frame3=tk.Frame(score_frame)

recipe1_set_button=tk.Button(frame3, text="set1", command=set_recipe1)
recipe1_set_button.grid(row=0,column=0)

recipe2_set_button=tk.Button(frame3, text="set2", command=set_recipe2)
recipe2_set_button.grid(row=0,column=1)

score_search_button = tk.Button(frame3, text="Search_both", command=calculate_score_search)
score_search_button.grid(row=1,column=0)

# Add score button
score_button = tk.Button(frame3, text="Score", command=hit_cal)
score_button.grid(row=1,column=2)

# Add label for displaying score
score_label = tk.Label(score_frame, text="")
score_label.pack()

# Show home page by default
open_home()

root.mainloop()