import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
import pickle 

def find_sub(q):
    ing = pd.read_csv('D:\Food_pairing\my_food_pairing\data\Flavourgraph\\nodes_191120.csv')  

    embeddings_dict = pickle.load(open('D:\Food_pairing\my_food_pairing\data\Flavourgraph\embedings.pickle','rb')) 

    req_id=ing.loc[ing['name'] == q, 'node_id'].iloc[0]
    print(req_id)
    target_embeding=embeddings_dict[req_id]
    similarity_scores = {}
    for r_id, embedding in embeddings_dict.items():
            if r_id != req_id:
                similarity_scores[r_id] = cosine_similarity(target_embeding.reshape(1,-1), embedding.reshape(1,-1))[0]

    x=sorted(similarity_scores.items(), key=lambda x: x[1], reverse=True)
    y=[]
    for i in x[:5]:
       y.append(ing[ing["node_id"]==i[0]]["name"].iloc[0])
    return y