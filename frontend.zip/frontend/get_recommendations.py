from search_simillar_recipe import find_similar_recipes
import random
from search_simillar_recipe import find_similar_recipes
def get_recommendations(preferences,recipe_embedings):
    if(len(preferences)==0 ):
        x=[]
        for i in range(5):
          x.append(random.choice(list(recipe_embedings.keys())))
        return x

    l=dict()
    for i in preferences:
        l.update(find_similar_recipes(i,recipe_embedings))
    x= random.sample(l.keys(),6)
    return x


