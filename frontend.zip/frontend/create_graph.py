import networkx as nx
import pandas as pd
from tqdm import tqdm, trange
import pickle
graph = nx.Graph()
graph_ingr_only = nx.Graph()
df_nodes = pd.read_csv("D:\Food_pairing\\final\data\Flavourgraph\\nodes_191120.csv")
for index, row in tqdm(df_nodes.iterrows(), total=len(df_nodes)):
    node_id, name, _id, node_type, is_hub = row.values.tolist()
    graph.add_node(node_id, name=name, id=_id, type=node_type, is_hub=is_hub)
    if node_type == 'ingredient':
        graph_ingr_only.add_node(node_id, name=name, id=_id, type=node_type, is_hub=is_hub)

print("Edges Loaded...%s..." % format("D:\Food_pairing\\final\data\Flavourgraph\edges_191120.csv"))
df_edges = pd.read_csv("D:\Food_pairing\\final\data\Flavourgraph\edges_191120.csv")
for index, row in tqdm(df_edges.iterrows(), total=len(df_edges)):
    #print(row.values.tolist())
    id_1, id_2, score, edge_type = row.values.tolist()
    graph.add_edge(id_1, id_2, weight=score, type=edge_type)
    if edge_type == 'ingr-ingr':
        graph_ingr_only.add_edge(id_1, id_2, weight=score, type=edge_type)

#graph.remove_edges_from(graph.selfloop_edges())
#graph_ingr_only.remove_edges_from(graph.selfloop_edges())

print("\nThe whole graph - ingredients, food-like compounds, drug-like compounds")
print("# of nodes in graph: %d" % nx.number_of_nodes(graph))
print("# of edges in graph: %d" % nx.number_of_edges(graph))

with open("D:\Food_pairing\\final\data\output\graph_all","wb") as f:
    pickle.dump(graph,f)
with open("D:\Food_pairing\\final\data\output\graph_only_ing","wb") as f:
    pickle.dump(graph,f)
