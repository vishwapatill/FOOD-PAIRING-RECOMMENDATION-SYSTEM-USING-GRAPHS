import pandas as pd
from fuzzywuzzy import process
import pickle
# Load the datasets
recipes_df = pd.read_csv('D:\Food_pairing\my_food_pairing\data\indianRecepies\processed.csv')
ingredients_df = pd.read_csv('D:\Food_pairing\my_food_pairing\data\Flavourgraph\\nodes_191120.csv')

# Preprocess the datasets
recipes_df['Cleaned-Ingredients'] = recipes_df['Cleaned-Ingredients'].str.lower()
ingredients_df['name'] = ingredients_df['name'].str.lower()

def find_best_match(x,ly):
    y=x.split(',')
    z=[]
    c=0
    for i in y:
        best_match, score= process.extractOne(i,ly)
        if(score>=90):
            y[c]=best_match
            z.append(ingredients_df.loc[ingredients_df['name']== best_match,].iloc[0][0])
        else:
            z.append(-1)
        c+=1
    
    return y,z

d=[]
for i in ingredients_df['name']:
    d.append(i)

d1={}
d2={}
for i in range(0,10):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name1","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id1","wb"))



# v=pickle.load(open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id1",rb))
# print(v)
print("-----------------0%---------------")
d1={}
d2={}
for i in range(10,1000):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name1000","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id1000","wb"))

print("-----------------10%---------------")
d1={}
d2={}
for i in range(1000,2000):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a 
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name2000","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id2000","wb"))

print("-----------------20%---------------")
d1={}
d2={}
for i in range(2000,3000):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name3000","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id3000","wb"))
print("-----------------40%---------------")
d1={}
d2={}
for i in range(3000,4000):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name4000","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id4000","wb"))

print("-----------------60%---------------")
d1={}
d2={}
for i in range(4000,5000):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name5000","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id5000","wb"))

print("-----------------80%---------------")

d1={}
d2={}
for i in range(5000,5936):
    a,b=find_best_match(recipes_df.iloc[i,5],d)
    d1[i]=a
    d2[i]=b

pickle.dump(d1,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipe_ingredient_name5936","wb"))
pickle.dump(d2,open("D:\Food_pairing\my_food_pairing\data\pickle_files\\recipie_ingredient_id5936","wb"))
    