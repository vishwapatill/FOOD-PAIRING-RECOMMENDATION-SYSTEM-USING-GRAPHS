import pandas as pd

def get_Rec_name(i):
    df = pd.read_csv('D:\Food_pairing\\final\data\indianRecepies\processed.csv')
    column_index = df.columns.get_loc("TranslatedRecipeName")
    return df.iloc[i, column_index]


